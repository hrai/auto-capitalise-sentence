
$(document).ready(function(){
    var sitesToExclude = [];

    console.log('test');

    $('#submitButton').click(function() {
        var sitesBox = $('#sites');
        console.log(sitesBox.val());
    });
});


